#include "Queue.h"
int last_occurrence_linear_search(const vector<int>& v, int target, int index) {
    if (index < 0) {
        return -1; // Target not found
    }
    if (v[index] == target) {
        return index; // Found last occurrence
    }
    return last_occurrence_linear_search(v, target, index - 1);
}

void insertion_sort_queue(Queue& q) {
    //Base case
    if (q.empty()) {
        return;
    }

    // Recursive case
    int current_value;
    Queue sorted_queue;
    sorted_queue.push(q.front());
    q.pop();

    while (!q.empty()) {
        current_value = stoi(q.front()); // Convert the string to an int
        q.pop();

        while (!sorted_queue.empty() && stoi(sorted_queue.front()) < current_value) {
            q.push(sorted_queue.front()); // Move elements back to the original queue
            sorted_queue.pop(); // Remove the element from the sorted queue
        }
        sorted_queue.push(to_string(current_value)); // Convert the int to a string before pushing
    }

    // Copy the sorted elements back to the original queue
    while (!sorted_queue.empty()) {
        q.push(sorted_queue.front());
        sorted_queue.pop();
    }
}

int main() {
  Queue Line;
  Line.push("Hunter");
  cout << Line.front() << " is in the front." << endl;
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  Line.push("Trenton");
  if(Line.empty() == 0){
    cout << "Line is not empty." << endl;
  }
  else
    cout << "Line is empty." << endl;
  cout << "Size of line: " << Line.size() << endl;
   while (!Line.empty()) {
      cout << Line.front() << endl;
      Line.pop();
    }
  cout << Line.front() << " is in the front." << endl;

}